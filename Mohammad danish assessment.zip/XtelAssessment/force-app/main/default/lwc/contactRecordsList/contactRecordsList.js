import { LightningElement,api,wire,track } from 'lwc';
import findContactByAccountId from '@salesforce/apex/ContactController.findContactByAccountId';
import searchContacts from '@salesforce/apex/ContactController.searchContacts';

export default class ContactRecordsList extends LightningElement {
    columns =  [
        { label: 'First Name', fieldName: 'FirstName',sortable:true },
        { label: 'Last Name', fieldName: 'LastName', sortable:true},
        { label: 'Email', fieldName: 'Email', type: 'email',sortable:true },    
    ];
    @api accountId;
    @track searchkey;
    @track contacts;
    @track contactId;

        // method to find related list
    //@wire(findContactByAccountId,{accountId:'$accountId'}) contacts;  ,conToSearch:`$searchkey`
    @wire(findContactByAccountId,{accountId:'$accountId'}) 
    getRelContactList({error,data}){
        if(data){
            this.contacts = data;
        }
        else if(error){
            this.contacts = error;
        }
        
    };    
  
    handleSortData(event) {       
        let fieldName = event.detail.fieldName;       
        let sortDirection = event.detail.sortDirection; 
        this.sortedBy = fieldName;
        this.soretedDirection = sortDirection;      
        this.contacts = this.sortData(fieldName, sortDirection);
        console.log(this.contacts);
        console.log(event.detail.sortDirection);
    }

    sortData(fieldname, direction) {       
       console.log('contacts records:::'+this.contacts);
      // this.contacts = '';a
       let parseData = JSON.parse(JSON.stringify(this.contacts));
       console.log('parse data:::'+parseData);
        let keyValue = (a) => {
            return a[fieldname];
        };

       let isReverse = direction === 'asc' ? 1: -1;

           parseData.sort((x, y) => {
            x = keyValue(x) ? keyValue(x) : ''; 
            y = keyValue(y) ? keyValue(y) : '';
           
            return isReverse * ((x > y) - (y > x));
        });
        
        this.contacts = parseData;

    }

}